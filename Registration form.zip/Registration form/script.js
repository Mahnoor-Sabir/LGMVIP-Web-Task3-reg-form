document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("registration-form");
    const output = document.getElementById("output");

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const phone = document.getElementById("phone").value;
        const course = document.getElementById("course").value;
        const comments = document.getElementById("comments").value;
        const gender = document.querySelector('input[name="gender"]:checked').value;
        const website = document.getElementById("website").value;
        const skills = document.getElementById("skills").value;
        const image = document.getElementById("image").files[0];

        const formData = `
            <p>Name: ${name}</p>
            <p>Email: ${email}</p>
            <p>Phone: ${phone}</p>
            <p>Course: ${course}</p>
            <p>Comments: ${comments}</p>
            <p>Gender: ${gender}</p>
            <p>Website: <a href="${website}" target="_blank">${website}</a></p>
            <p>Skills: ${skills}</p>
        `;

        output.innerHTML = formData;

        // Handle image upload (display image)
        if (image) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const imageElement = document.createElement("img");
                imageElement.src = e.target.result;
                imageElement.classList.add("uploaded-image");
                output.appendChild(imageElement);
            };
            reader.readAsDataURL(image);
        }
    });
});
